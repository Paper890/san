from ftvpn import *

#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.edit('**𝙐𝙨𝙚𝙧𝙣𝙖𝙢𝙚:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.edit("**𝙌𝙪𝙤𝙩𝙖:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as ip:
			await event.edit("**𝙇𝙞𝙢𝙞𝙩 𝙄𝙋:**")
			ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			ip = (await ip).raw_text
		async with bot.conversation(chat) as exp:
			await event.edit("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await event.edit("`Processing Crate Premium Account`")
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | add-ws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
#			c = [x.group() for x in re.finditer("Host XrayDNS(.*)",a)]
#			d = [x.group() for x in re.finditer("Pub Key(.*)",a)]
			print(b)
#			print(d)
#			print(c)
#			xx = re.search("Pub Key      :(.*)",d[0]).group(1)
#			xxx = re.search("Host XrayDNS :(.*)",d[0]).group(1)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Vmess Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{z["ps"]}`
**» Domain      :** `{z["add"]}`
**» Ns DNS      :** `{HOST}`
**» Port DNS    :** `443, 53`
**» port TLS    :** `443`
**» Port NTLS   :** `80, 8080`
**» Port GRPC   :** `443`
**» AlterId     :** `0`
**» Security    :** `auto`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/whatever/vmess`
**» ServiceName :** `vmess-grpc`
**» User ID     :** `{z["id"]}`
**» Pub Key     :** `{PUB}`
**◇━━━━━━━━━━━━━◇**
**» Link TLS     :** 
`{b[0].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
`{b[1].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
`{b[2].strip("'")}`
**◇━━━━━━━━━━━━━◇**
**» Format OpenClash :** `https://{DOMAIN}:81/vmess-{user}.txt`
**◇━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**» 🤖@fightertunnell**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("access denied ❌",alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await event.edit("`Processing Crate Premium Account`")
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | trial-ws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**◇━━━━━━━━━━━━━◇**
**⟨ Xray/Vmess Account ⟩**
**◇━━━━━━━━━━━━━◇**
**» Remarks     :** `{z["ps"]}`
**» Domain      :** `{z["add"]}`
**» Ns DNS      :** `{HOST}`
**» Port DNS    :** `443, 53`
**» port TLS    :** `443`
**» Port NTLS   :** `80, 8080`
**» Port GRPC   :** `443`
**» AlterId     :** `0`
**» Security    :** `auto`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/whatever/vmess`
**» ServiceName :** `vmess-grpc`
**» User ID     :** `{z["id"]}`
**» Pub Key     :** `{PUB}`
**◇━━━━━━━━━━━━━◇**
**» Link TLS    :** 
`{b[0].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link NTLS   :** 
`{b[1].strip("'").replace(" ","")}`
**◇━━━━━━━━━━━━━◇**
**» Link GRPC   :** 
`{b[2].strip("'")}`
**◇━━━━━━━━━━━━━◇**
**» Expired Until:** `{exp} Minutes`
**» 🤖@fightertunnell**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("access denied ❌",alert=True)

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bash /etc/ftvpn/modules/shell/bot-cek-ws'.strip()
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```{z}```
**Shows Logged In Users Vmess**
**» 🤖@fightertunnell**
""",buttons=[[Button.inline("‹🔸Main Menu🔸›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			j = """grep -E "^### " "/etc/vmess/.vmess.db" | cut -d ' ' -f 2-3 | nl -s ') '"""
			g = subprocess.check_output(j, shell=True).decode("ascii")
			await event.respond(g.strip())
			await event.respond("**input number only:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | del-ws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			print(a)
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def renew_vmess(event):
	async def renew_vmess_(event):
		async with bot.conversation(chat) as user:
			j = """grep -E "^### " "/etc/vmess/.vmess.db" | cut -d ' ' -f 2-3 | nl -s ') '"""
			g = subprocess.check_output(j, shell=True).decode("ascii")
			await event.respond(g.strip())
			await event.respond("**input number only:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.edit("**𝙌𝙪𝙤𝙩𝙖:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as ip:
			await event.edit("**𝙇𝙞𝙢𝙞𝙩 𝙄𝙋:**")
			ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			ip = (await ip).raw_text
		async with bot.conversation(chat) as exp:
			await event.edit("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | renew-ws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			print(a)
			msg = f"""
**Chnge Vmess Account Successfully
limit Quota {pw} GB limit Login IP {ip} Device
Expired On Account {exp} Day**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_vmess_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'mem-vmess'))
async def mem_ws(event):
	async def mem_ws_(event):
		cmd = 'bash /etc/ftvpn/modules/shell/bot-mem-ws'.strip()
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
**🤖@fightertunnell**
""",buttons=[[Button.inline("‹🔸Main Menu🔸›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await mem_ws_(event)
	else:
		await event.answer("access denied ❌",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" TRIAL VMESS ","trial-vmess"),
Button.inline(" CREATE VMESS ","create-vmess")],
[Button.inline(" CHECK VMESS ","cek-vmess"),
Button.inline(" DELETE VMESS ","delete-vmess")],
[Button.inline(" RENEW VMESS ","renew-vmess"),
Button.inline(" MEMBER VMESS ","mem-vmess")],
[Button.inline("‹🔸Main Menu🔸›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		msg = f"""
**◇━━━━━━━━━━━━━◇**
**   🥈VMESS MANAGER🥈**
**◇━━━━━━━━━━━━━◇**
**✨Service:** `VMESS`
**✨Domain:** `{DOMAIN}`
**✨Isp:** `{z["isp"]}`
**✨City:** `{z["country"]}`
**✨Total User:** `{vms.strip()}` 
**🤖@fightertunnell**
**◇━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("access denied ❌",alert=True)

