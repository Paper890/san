#!/bin/bash

# File konfigurasi
config_file="/etc/xray/config.json"

# Menghitung jumlah baris berdasarkan pola
vlx=$(grep -c -E "^#& " "$config_file")
let vla=$vlx/2

vmc=$(grep -c -E "^### " "$config_file")
let vma=$vmc/2

trx=$(grep -c -E "^#! " "$config_file")
let trb=$trx/2

ssx=$(grep -c -E "^#ss# " "$config_file")
let ssa=$ssx/2

# Menghitung jumlah pengguna sistem dengan UID >= 1000
ssh1=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)

# Total keseluruhan
total=$((vla + vma + trb + ssh1))
echo $total